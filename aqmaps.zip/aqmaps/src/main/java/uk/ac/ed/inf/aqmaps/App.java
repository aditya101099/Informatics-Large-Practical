package uk.ac.ed.inf.aqmaps;
import java.util.*;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.lang.reflect.Type;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mapbox.geojson.Feature;
import com.mapbox.geojson.Polygon;
import com.mapbox.turf.TurfJoins;
import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.Point;

/**
* App is the main entry point into the application, and contains the main drone algorithm.
* 
* @author s1807827
* 
*/
public class App {
	
	/**
	 * <p> This is the main method of the application. It takes a series of command-line arguments, instantiates the drone, flies it around, and outputs files pertaining to its flight.
	 * </p>
	 * @throws java.io.IOException - if there is a failure in reading or writing data from/to files.
	 * @throws java.io.InterruptedException - if there is a failure in reading or writing data from/to files.
	 */
    public static void main( String[] args ) throws IOException, InterruptedException {
    	
    	var day = args[0];
    	var month = args[1];
    	var year = args[2];
    	
        var date = year + "/" + month + "/" + day; // Use the args to set up the date in YYYY/MM/DD format
        var startingPosition = new Coordinate(Double.parseDouble(args[4]), Double.parseDouble(args[3])); // Use args to initialize the drone starting position
        var port = Integer.parseInt(args[6]); // Save the port into the variable
        var urlString = "http://localhost:" + port + "/maps/" + date + "/air-quality-data.json"; // Construct the url string: "http://localhost:port/maps/YYYY/MM/DD/air-quality-data.json"
        final HttpClient client = HttpClient.newHttpClient(); // Create HTTP client
        var request = HttpRequest.newBuilder().uri(URI.create(urlString)).build(); // Get ready to issue request to fetch json file

        var response = client.send(request, BodyHandlers.ofString()); // Fetch json file
        
        var noFlyURL = "http://localhost:" + port + "/buildings/no-fly-zones.geojson";
        
        var noFlyZones = ReadWrite.getBuildings(client, noFlyURL);
        
        Type listType = new TypeToken<ArrayList<Sensor>>() {}.getType(); // generic type to de-serialize list data
      
        ArrayList<MoveData> moves = new ArrayList<MoveData>(); // initialize empty arraylist of moves
        ArrayList<Sensor> sensorList = new Gson().fromJson(response.body(), listType); // Pass json data into an arraylist of sensors
        ArrayList<Sensor> visitedSensors = new ArrayList<Sensor>(); // Make a blank arraylist of sensors to hold unvisited ones
    	ArrayList<Feature> markers = new ArrayList<Feature>(); // make a blank arraylist to hold all the feature markers

        
        var dronie = new Drone(startingPosition, client, port, moves, sensorList, visitedSensors, markers); // Initialize drone as per constructor
        
        var flightplan = new FlightPlan(sensorList, client, port, startingPosition); // initialize flight plan 
        

        
        flightplan.tuneFlightPlan(); // Optimize flight plan as per the greedy algorithm, swap heuristic, 2-opt heuristic
        
        System.out.println("Tuned perm "); // Prints the cost of the tuned permutation
        var tuned_perm = "";
        for (int o = 0; o < flightplan.perm.length; o++) {
        	var thispart = flightplan.perm[o] + ", ";
            tuned_perm += thispart;

        }
        
        System.out.println(tuned_perm); 

        // Fly the drone around
        

        	for (int idx: flightplan.getPerm()) { // Iterate through the indices of sensors in the tuned flightplan
            	var sensorToVisit = sensorList.get(idx); // Get the relevant sensor
            	var sensorCoordinates = ReadWrite.toCoordinates(sensorToVisit.getLocation(), client, port); // Get the coordinates of the sensor in (long, lat)
            	
            	var heading = dronie.calculateHeading(sensorCoordinates); // get the direction the sensor is in from the drone's current position
            	dronie.setHeading(heading); // set the drone's current heading to that heading
            	
              // The drone has to make a move, even if it is not in range to take a reading 
            	while (dronie.inNoFlyZone(noFlyZones)) { // While the drone is in a No-Fly Zone, keep turning right by 10 degrees (relative to where the drone is facing)
               		heading -= 10;                       // Until the drone is no longer going to move into a no fly zone
               		heading = (heading + 360) % 360;
            		dronie.setHeading(heading);
            	}
            	
            	if (dronie.moveCount < 150) { // Enforcing the 150 move limit
            		
            		dronie.move(heading); // Move in the direction, and if the drone is within 0.0002 degrees, take the sensor reading
                	if (Coordinate.getDistance(dronie.getPosition(), sensorCoordinates) < 0.0002) {
                		dronie.takeReading(sensorToVisit);
                	}
            		
            	}
            	


                     //   If the sensor is not within 0.0002 degrees and has moves to expend, then continue moving towards the sensor             
            	while (Coordinate.getDistance(dronie.getPosition(), sensorCoordinates) >= 0.0002 && dronie.moveCount < 150) {
                	heading = dronie.calculateHeading(sensorCoordinates);
                	dronie.setHeading(heading);


                	while (dronie.inNoFlyZone(noFlyZones)) { // Same No-Fly Zone logic as before
                   		heading -= 10;
                   		heading = (heading + 360) % 360;
                		dronie.setHeading(heading);
                	}
                	dronie.move(heading);

                	
                }
            	
                 dronie.takeReading(sensorToVisit); // If close enough to the sensor, take the reading
           
            }
        	
        	// Once it's done visiting the sensors, it's time to go back home!

         var returnHomeHeading = dronie.calculateHeading(startingPosition); // Find the heading needed to go home
         dronie.setHeading(returnHomeHeading);
         
         while (Coordinate.getDistance(dronie.getPosition(), startingPosition) >= 0.0003 && dronie.moveCount < 150) { // Check that we are not right next to home by default and enforce the move limit
           while (dronie.inNoFlyZone(noFlyZones)) { // same no fly zones logic as before
       		returnHomeHeading -= 10;
       		returnHomeHeading = (returnHomeHeading + 360) % 360;
        	  dronie.setHeading(returnHomeHeading);
           }
               
           dronie.move(returnHomeHeading);
           
           returnHomeHeading = dronie.calculateHeading(startingPosition); // recalculate heading
           
           dronie.setHeading(returnHomeHeading); // set the new heading
      }
//        

         // Time to get ready for writing to the file!
        
        
        markers = dronie.getMarkers(); // Get all the markers for the sensors that have been visited
        moves = dronie.getMoves(); // Get all the MoveData objects to describe the history of the drone's movement
        visitedSensors = dronie.getVisitedSensors(); // Get all the visited sensors
        var unvisitedSensors = dronie.getSensorList(); // Get all of the sensors list as the unvisited sensors, we will determine which ones are unvisited momentarily
        
    	var unvisitedMarkers = new ArrayList<Feature>(); // Make a list of unvisited markers
    	
        for (Sensor unvisitedSensor: unvisitedSensors) { // Iterate through the sensors
        	
        	if (!visitedSensors.contains(unvisitedSensor)) { // If any of the sensors are NOT in the visited sensors list
            	unvisitedMarkers.add(ReadWrite.makeUnfinishedMarker(unvisitedSensor.getLocation(), client, port)); // Then make the grey, unvisited marker and add it to the list

        	}
        }
        
        var dronePath = ReadWrite.makeLine(moves); // Connect all drone moves together to make one interrupted LineString flight path
        
        
        // Put all features into the same file

        
        var allFeatures = new ArrayList<Feature>(); // Make a new arraylist that will have all markers + flight path
        allFeatures.addAll(markers); // Add all markers for visited sensors
        allFeatures.addAll(unvisitedMarkers); // Add all markers for unvisited sensors (might result in adding nothing)
        allFeatures.add(dronePath); // Add the drone path line string
        

        // Write to file
        
        var movesFilename = "flightpath-" + day + "-" + month + "-" + year + ".txt"; // filename for flightpath.txt
        var readingsFilename = "readings-" + day + "-" + month + "-" + year + ".geojson"; // filename for readings.geojson

        
        ReadWrite.writeMovesToFile(movesFilename, moves); // output flightpath.txt file

        ReadWrite.writeReadingstoGeoJSON(readingsFilename, allFeatures); // output readings.geojson file
        
        System.out.println("Task successfully completed.");
        

 
    }
}
