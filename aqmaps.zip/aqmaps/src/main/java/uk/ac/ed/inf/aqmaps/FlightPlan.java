package uk.ac.ed.inf.aqmaps;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.*;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
* FlightPlan is the main entity that determines the optimal flight path for the drone to fly in.
* 
* @author s1807827
* 
*/

public class FlightPlan {
	
	/**
	 * A list of the sensors the drone must visit.
	 */
	private final ArrayList<Sensor> sensors;
	
	/**
	 * A matrix containing the distances between any pair of sensors in the geographical area.
	 */
	private final double[][] dists;
	
	/**
	 * An array of the indices of the sensors which the drone must visit; the order is the permutation for the drone to visit.
	 */
	public int[] perm;
	
	/**
	 * The HttpClient the drone uses to connect to the web server.
	 */
	private HttpClient client;
	
	/**
	 * The port on which the drone connects to the web server.
	 */
	private int port;
	


	/**
	 * The number of sensors the drone needs to visit.
	 */
	public int numberOfSensors;
	
	/**
	 * The drone's starting position, expressed as a Coordinate.
	 */
	private Coordinate startingPosition;
	
	
	/**
	 * Creates the initial flight plan, computes the distances between all the sensors, sets the default permutation to the identity permutation.
	 */
	public FlightPlan(ArrayList<Sensor> sensors, HttpClient client, int port, Coordinate startingPosition) {
		
		this.numberOfSensors = sensors.size(); // Calculate the number of sensors - although this is 33, this code can enable it to expand arbitrarily

		this.client = client;
		this.port = port;
		this.startingPosition = startingPosition;
		this.dists = new double[this.numberOfSensors][this.numberOfSensors]; // Declare the adjacency matrix to be of size numberOfSensors x numberOfSensors
		this.sensors = sensors;

		var sensorLocations = new ArrayList<Coordinate>(); // Create an ArrayList of all the coordinates of the sensors
		
		for (int sensorIndex = 0; sensorIndex < this.numberOfSensors; sensorIndex++) { // Iterate through each sensors
			sensorLocations.add(ReadWrite.toCoordinates(sensors.get(sensorIndex).getLocation(), client, port)); // Convert What3Words address to coordinates
		}

		
		for (int i = 0; i < this.numberOfSensors; i++) { // Iterate through the first dimension of the adjacency matrix 
			for (int j = 0; j < this.numberOfSensors; j++) { // Iterate through the second dimension of the adjacency matrix
				if (i != j) {
					this.dists[i][j] = Coordinate.getDistance(sensorLocations.get(i), sensorLocations.get(j)); // Find the distance between any pair of sensors and save it into the relevant matrix element

				}
			}
		}
			
		this.perm = IntStream.range(0, numberOfSensors).toArray(); // Declare the permutation to be the identity permutation: [0, numberOfSensors]
		

	}
	
	/**
	 * <p> This method returns the total cost (distance) of the path determined by the permutation of the sensors.
	 * </p>
	 * @return The total cost (distance) of the path determined by the permutation of the sensors.

	 */
	public double tourValue() {
        var finalCost = 0.0; // Declare the total distance/cost to be 0 
        var costPairs = new ArrayList<int[]>();
        
        for (int i = 0; i < this.perm.length - 1; i++) {
        	costPairs.add(Arrays.copyOfRange(this.perm, i, i+2)); // Add every pair of consecutive elements in the permutation to the costpairs list
        }
        
        var wraparound = new int[2]; // Make the nth and 0th element a pair and add it
        wraparound[0] = this.perm[this.perm.length-1];
        wraparound[1] = this.perm[0];

        costPairs.add(wraparound);
        for (int[] c: costPairs) { // Iterate through costPairs
        	finalCost += this.dists[c[0]][c[1]]; // Look up the distance between the sensors denoted by the first and second elements of each costPair; add to finalCost
        }
        return finalCost;
	}
	
	/**
	 * <p> This method determines the permutation of sensors to given in by iterating through the sensors and picking the next sensor to visit to be the closest sensor to that sensor. It is a greedy best-first search approach.
	 * </p>
	 */
    private void Greedy() {
        var usedNodes = new ArrayList<Integer>(); // Make a list of the sensors that have been accounted for
        var closestSensorToDroneStart = 0; // Index of the closest sensor to the drone's starting position
        var distanceBetweenSensorsAndStart = new ArrayList<Double>(); // This will hold the distance between each sensor and the drone's starting position
        
        for (int i = 0; i < numberOfSensors; i++) { // Iterate through the number of sensors
        	distanceBetweenSensorsAndStart.add(Coordinate.getDistance(ReadWrite.toCoordinates(sensors.get(i).getLocation(), client, port), startingPosition)); // Add the distance between each sensor to the list
        }
        
        var leastDistanceToSensorFromStart = distanceBetweenSensorsAndStart.get(0); // Define the smallest distance to be that between the starting position of the drone and the first sensor in the list
        
        for (int k = 0; k < numberOfSensors; k++) { // Iterate through the list of distances
        	var distance = distanceBetweenSensorsAndStart.get(k);
        	if (distance < leastDistanceToSensorFromStart) { // If any are less than the currently-known shortest distance, make that distance the shortest-known distance and update the index of the closest sensor to the drone's starting position
        		leastDistanceToSensorFromStart = distance;
        		closestSensorToDroneStart = k;
        	}
        }
        
       
        usedNodes.add(closestSensorToDroneStart); // Add the closest sensor to the drone's starting position to the visited sensors
                
        var minValues = new ArrayList<Double>(); // Make a list of the minimum values 
        while (usedNodes.size() < numberOfSensors) { // While there are still sensors to visit
            var lastItem = usedNodes.get(usedNodes.size()-1); // Get the last sensor visited
            for (int j = 0; j < numberOfSensors; j++) {
                if ((lastItem != j) && !(usedNodes.contains(j))) {
                    minValues.add(dists[lastItem][j]); // Find the distances between all remaining sensors and the last sensor, add it to minVlaues
                }

            }
            
            var minDist = minValues.get(0);
            
            
            for(int x = 0; x < minValues.size(); x++ ){ // This code
            	var value = minValues.get(x);          // finds the smallest distance between the last sensor and all remaining sensors
            	   if (value < minDist) {
            	      minDist = value;
            	   }
            	}
            
            for (int i = 0; i < numberOfSensors; i++) { // Iterate through the remaining sensors, and add the one with the smallest distance between it and the last one to the usedNodes list
                if ((lastItem != i) && (minDist == dists[lastItem][i]) && !((usedNodes.contains(i)))) {
                    usedNodes.add(i);
                    break;
                }
            }
            
            
            minValues.clear(); // Clear the list of min values to make way for the next iteration of the for loop
        }
        
     // This code  converts the usedNodes to an array, and sets the permutation equal to that 
        Object[] usedArray = usedNodes.toArray(); 
        
        System.out.println("Greedy Perm");
        
  
        var greedy_perm = "";


        for (int o = 0; o < usedArray.length; o++) { // Prints out the tour value given the greedy algorithm
            perm[o] = (int) usedArray[o];
        	var thispart = this.perm[o] + ", ";
            greedy_perm += thispart;

        }
        
        System.out.println(greedy_perm);
        
        System.out.println(this.tourValue() + " - Greedy tour value");
        
        


    }
	
	/**
	 * <p> This method determines if switching the order of two sensors in the permutation at indices i and i+1 will result in a shorter path.
	 * </p>
	 * @param i - the index of the sensor to switch with its next index value.
	 * @return A boolean stating if swapping the sensors resulted in a shorter path - if false, it reverts to the original permutation. If true, it commits to the new permutation.

	 */
    private boolean trySwap(int i) {
        var result = true;
        var originalCost = this.tourValue(); // calculate original cost of tour
        var swap1 = this.perm[i]; // Swaps the index of the ith value
        this.perm[i] = this.perm[(i+1) % this.numberOfSensors]; // and the i+1th value with one another
        this.perm[(i+1) % this.numberOfSensors] = swap1;
        var newCost = this.tourValue(); // Calculate cost of tour given the swap
        if (originalCost < newCost) { // If this results in a regression, then revert
            var backToBeginning = this.perm[i];
            this.perm[i] = swap1;
            this.perm[(i+1) % this.numberOfSensors] = backToBeginning;
            result = false;
        }
        return result; // Return either the committed permutation or the original 
    }
    
	/**
	 * <p> This method swaps a sensor with the sensor at its next index value for each possible sensor pair such that the resultant tour value is minimized.
	 * </p>
	 */
    private void swapHeuristic() {
        var better = true;
        while (better) {
            better = false;
            for (int i = 0; i < this.numberOfSensors; i++)  { // Try all possible swaps and keep picking the smallest tour value
                if (this.trySwap(i)) {
                    better = true;
                }
            }
        }
    }
    
	/**
	 * <p> This method reverses the segment of the flightpath between indices i and j, and commits to the reversal if it improves the tour value.
	 * </p>
	 * @param i - the starting index of the segment
	 * @param j - the ending index of the segment
	 * @return A boolean stating if reversing the segment resulted in a shorter path - if false, it reverts to the original permutation. If true, it commits the new permutation.
	 */
	private boolean tryReverse(int i, int j) {
        var originalCost = this.tourValue(); // save original tour value
        var originalPerm = this.perm; // and original permutation
        
        

        // This code finds the array slices, reverses the relevant segment, and stitches them all together into one master array, called new_perm
        var part_one = Arrays.copyOfRange(this.perm, 0, i);
        var part_two = Arrays.copyOfRange(this.perm, i, j+1);
        var temp = Arrays.copyOfRange(this.perm, j+1, this.numberOfSensors);
        int[] part_three = IntStream.rangeClosed(1, temp.length).map(k -> temp[temp.length-k]).toArray();

        var part_one_and_two = new int[part_one.length + part_two.length];

        System.arraycopy(part_one, 0, part_one_and_two, 0, part_one.length);
        System.arraycopy(part_two, 0, part_one_and_two, part_one.length, part_two.length);
                
                
        var new_perm = new int[part_one_and_two.length + part_three.length];
        System.arraycopy(part_one_and_two, 0, new_perm, 0, part_one_and_two.length);
        System.arraycopy(part_three, 0, new_perm, part_one_and_two.length, part_three.length);

        this.perm = new_perm;
        
        
        // Compare tour values, and commit if better

        if (this.tourValue() > originalCost - 0.00000000001) { // Subtraction of infinitesimally small number is to account for floating point errors
           this.perm = originalPerm;
           return false;
        } else {
           return true;
        }
    }
	
	/**
	 * <p> This method reverses every possible segment (i, j) for all i, j < the number of sensors, and commits the new permutation.
	 * </p>
	 */
    private void TwoOptHeuristic() {
        var better = true;
        while (better) {
            better = false;
            for (int j = 0; j < this.numberOfSensors; j++) {
                for (int i = 0; i < j; i++) {
                    if (this.tryReverse(i,j)) {
                        better = true;
                    }
                }
            }
        }
    }

	/**
	 * <p> This method finds the optimal flightpath. It first conducts a greedy best-first search, then performs a swap heuristic to tune it, and then finally tunes that even further by performing the Two-Opt heuristic.
	 * </p>
	 */
	public void tuneFlightPlan() {		
		
		this.Greedy(); // First performs greedy on the identity permutation
		this.swapHeuristic(); // Then performs swap on the greedy permutation
		this.TwoOptHeuristic(); // Then performs Two-Opt on the swap+greedy permutation

        
        System.out.println(this.tourValue() + " - Tuned tour value"); // Print out the new tuned tour value
    }
	
	/**
	 * <p> This method returns the permutation of the sensors which the drone should visit.
	 * </p>
	 */
	public int[] getPerm() {
		return perm;
	}

	/**
	 * <p> This method returns the number of sensors the drone needs to visit.
	 * </p>
	 */
	public int getNumberOfSensors() {
		return numberOfSensors;
	}
	
	

}
