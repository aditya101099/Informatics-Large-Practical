package uk.ac.ed.inf.aqmaps;

/**
* Sensor is the main entity that models the sensor state.
* 
* @author s1807827
* 
*/
public class Sensor {
	
	/**
	* The location of the sensor, as a What3Words address.
	*/
	public final String location;
	
	/**
	* The battery level of the sensor, which ranges between 0 and 100.
	*/
	public final double battery;
	
	/**
	* The reading of the sensor.
	*/
	public final String reading;
	
	public Sensor(double battery, String reading, String location, boolean visited) {
		this.location = location;
		this.battery = battery;
		this.reading = reading;
	}

	/**
	 * <p> This method returns the sensor's current battery level.
	 * </p>
	 * @return The sensor's current battery level.
	 */
	public double getBattery() {
		return battery;
	}

	/**
	 * <p> This method returns the sensor's reading.
	 * </p>
	 * @return The sensor's current reading.
	 */
	public String getReading() {
		return reading;
	}

	/**
	 * <p> This method returns the sensor's current location, as a What3Words address.
	 * </p>
	 * @return The sensor's current location, as a What3Words address.
	 */
	public String getLocation() {
		return location;
	}



}
