package uk.ac.ed.inf.aqmaps;
import com.mapbox.geojson.*;
import java.util.*;
import java.io.*; 
import java.net.http.HttpClient;
import com.mapbox.turf.*;

/**
* Drone is the main entity that models the drone state and controls its behavior.
* 
* @author s1807827
* 
*/

public class Drone {
	
	/**
	 * The current position of a drone, as specified by its longitude and latitude.
	 */
	public Coordinate position;
	
	/**
	 * The direction the drone is facing in degrees, where 0 is due East on a compass rose, and 180 is due West.
	 */
	public int heading;
	
	/**
	 * The number of moves the drone has made.
	 */
	public int moveCount;
	
	/**
	 * The HttpClient the drone uses to connect to the web server.
	 */
	private HttpClient client;
	
	/**
	 * The port on which the drone connects to the web server.
	 */
	private int port;
	
	/**
	 * A list of MoveData objects that contain details of the drone's move history.
	 */
	public ArrayList<MoveData> moves;
	
	/**
	 * A list of the sensors the drone must visit.
	 */
	public ArrayList<Sensor> sensorList;
	
	/**
	 * A list of the sensors the drone has visited and taken a reading from.
	 */
	public ArrayList<Sensor> visitedSensors;
	
	/**
	 * A list of GeoJSON markers the drone has placed for each sensor location that it has visited and taken a reading from.
	 */
	public ArrayList<Feature> markers;

	 	
	// Constructor, initializes everything.
	public Drone(Coordinate position, HttpClient client, int port, ArrayList<MoveData> moves, ArrayList<Sensor> sensorList, ArrayList<Sensor> visitedSensors, ArrayList<Feature> markers) {
		this.position = position;
		this.heading = 0;
		this.moveCount = 0;
		this.client = client;
		this.port = port;
		this.moves = moves;
		this.sensorList = sensorList;
		this.visitedSensors = visitedSensors;
		this.markers = markers;

	}
	
	
	/**
	 * <p> This method enables the drone to take a reading once it is sufficiently close (within 0.0002 degrees) to a sensor, and adds the relevant marker for that sensor to the drone's list of markers.
	 * </p>
	 * @param sensor - the sensor object which it needs to read

	 */
	
	public void takeReading(Sensor sensor) {
		this.visitedSensors.add(sensor); // Add sensor to visitedSensors list
		
		var rgbString = sensor.getBattery() >= 10.0 ? ReadWrite.readingToHex(sensor.getReading()) : ReadWrite.readingToHex("-1"); // If the battery is more than or equal to 10%, derive the corresponding color value for the reading. Else, it will be black. 
		var markerSymbol = sensor.getBattery() >= 10.0 ? ReadWrite.readingToMarker(sensor.getReading()) : ReadWrite.readingToMarker("-1");  // If the battery is more than or equal to 10%, derive the corresponding marker symbol for the reading. Else, it will be a cross. 
		this.markers.add(ReadWrite.makeMarker(rgbString, markerSymbol, sensor.getLocation(), client, port)); // Add marker to list of markers
		
		var last_move_idx = this.moves.size() - 1; // Get the index of the last move in the list of MoveData objects
		var last_move = this.moves.get(last_move_idx); // Get the last MoveData object
		last_move.setW3w(sensor.getLocation()); // Set its location to the location of the sensor we have just read, rather than "null"
		this.moves.set(last_move_idx, last_move); // Override the last MoveData object in the list of moves with the updated one

			
	}
	
	/**
	 * <p> This method enables the drone to move 0.0003 degrees in the given direction.
	 * </p>
	 * @param heading - the direction it needs to move in.

	 */
	public void move(int heading) {
		this.heading = heading; // Sets the heading 
		var destLong = this.getLongitude() + 0.0003*Math.cos(Math.toRadians(heading)); // Find the change in x as per trigonometry
		var destLat = this.getLatitude() + 0.0003*Math.sin(Math.toRadians(heading)); // Find the change in y as per trigonometry
		this.moveCount += 1; // Increment the number of moves
	
		
		
		
		var thisMove = new MoveData(this.moveCount, this.getLongitude(), this.getLatitude(), this.heading, destLong, destLat, null); // Create the MoveData object for this move

		setPosition(new Coordinate(destLong, destLat));	// Set the position of the drone to the new location
		this.moves.add(thisMove); // Add the MoveData object to the list of moves
		
		
		
	}
	
	/**
	 * <p> This method determines whether the drone is about to enter a No-Fly Zone in the next move.
	 * </p>
	 * @param noFlyZones - a list of No-Fly Zones, as GeoJSON Polygons.
	 * @return Whether or not the drone is about to enter a No-Fly Zone in the next move (true or false value).

	 */
	public boolean inNoFlyZone(ArrayList<Polygon> noFlyZones) {
		var nextPositions = this.calculateNextPositions(); // Break up the next move into 100 small segments, get all of them as a list 
		var result = false;
		
		for (Polygon noFlyZone: noFlyZones) { // Iterate through the no fly zones
			for (Point position: nextPositions) { // Iterate through the line segments
				result = result || TurfJoins.inside(position, noFlyZone); // Check if any of them are in a no fly zone
			}
		}
		return result; // if true, then at least one point is in at least one no fly zone. if false, the move is legal.
	}
	
	/**
	 * <p> This method determines the direction to travel in given a set of destination coordinates.
	 * </p>
	 * @param destination - The coordinates the drone needs to move towards.
	 * @return An int which is the direction the drone has to move in to get to the destination point.

	 */
	public int calculateHeading(Coordinate destination) {
		var delta_x = destination.getLongitude() - this.getLongitude(); // Find the change in x
		var delta_y = destination.getLatitude() - this.getLatitude(); // Find the change in y
		var newHeading = (Math.toDegrees(Math.atan2(delta_y, delta_x)) + 360) % 360; // Take the arctan of y/x to find the angle, convert to degrees, and conver to a domain of [0, 360[
		
		return (int) Math.round(newHeading / 10.0) * 10; // Round the angle to the nearest ten and return as an int

	}
	
	/**
	 * <p> This method splits a move of 0.0003 degrees into 100 small points, and is used by the inNoFlyZone() method to calculate whether any of the small points are in a No-Fly Zone.
	 * </p>
	 * @return An ArrayList of 100 points between the current position, and the position that is 0.0003 degrees away from the direction the drone is facing in.

	 */
	private ArrayList<Point> calculateNextPositions() {
		var output = new ArrayList<Point>(); // Initialize empty arraylist to hold the small line segments
		var currLong = this.getLongitude(); // Get current longitude
		var currLat = this.getLatitude(); // Get current latitude
		var heading = this.getHeading(); // Get current heading
		
		var distance = 0.0003/100; // Divide up a legal move into 100th of the distance
		
		for (int i = 1; i < 101; i++) { // Iterate through each line segment 
			var destLong = distance*i*Math.cos(Math.toRadians(heading)) + currLong; // Find the new long that is 3-millionths of a degree away
			var destLat = distance*i*Math.sin(Math.toRadians(heading)) + currLat; // Find the new lat that is 3-millionths of a degree away
			output.add(Point.fromLngLat(destLong, destLat)); // Convert to GeoJSON Point and add to the list
		}
		
		return output;
	}
	
	/**
	 * <p> This method sets the new position of the drone.
	 * </p>
	 * @param position - The new position of the drone.
	 */
	public void setPosition(Coordinate position) {
		this.position = position;
	}
	
	/**
	 * <p> This method returns the current position of the drone.
	 * </p>
	 * @return The position of the drone.
	 */
	public Coordinate getPosition() {
		return position;
	}
	
	
	/**
	 * <p> This method sets the direction the drone is facing in to the given heading.
	 * </p>
	 * @param heading - The direction the drone needs to face.
	 */
	public void setHeading(int heading) {
		this.heading = heading;
	}

	/**
	 * <p> This method returns the current heading of the drone.
	 * </p>
	 * @return The direction the drone is facing.
	 */
	public int getHeading() {
		return heading;
	}
	
	/**
		 * <p> This method returns the number of moves the drone has made.
		 * </p>
		 * @return The number of moves the drone has made.
	*/
	public int getMoveCount() {
		return moveCount;
	}
	
	/**
	 * <p> This method returns a list of MoveData objects that contain details on each move the drone has made.
	 * </p>
	 * @return A list of details on each move the drone has made.
	 */
	public ArrayList<MoveData> getMoves() {
		return moves;
	}
	
	/**
	 * <p> This method returns a list of the sensors the drone has to visit.
	 * </p>
	 * @return The list of sensors the drone has to visit.
	 */
	public ArrayList<Sensor> getSensorList() {
		return sensorList;
	}

	/**
	 * <p> This method returns a list of the sensors the drone has taken readings from.
	 * </p>
	 * @return The list of sensors the drone has taken readings from.
	 */
	public ArrayList<Sensor> getVisitedSensors() {
		return visitedSensors;
	}

	/**
	 * <p> This method returns a list of the markers the drone has created.
	 * </p>
	 * @return The list of markers for the sensors which the drone has taken readings from.
	 */
	public ArrayList<Feature> getMarkers() {
		return markers;
	}
	
	/**
	 * <p> This method returns the drone's current position's longitude.
	 * </p>
	 * @return The drone's current longitude.
	 */
	public double getLongitude() {
		return position.getLongitude();
	}
	
	/**
	 * <p> This method returns the drone's current position's latitude.
	 * </p>
	 * @return The drone's current latitude.
	 */
	public double getLatitude() {
		return position.getLatitude();
	}
	 
}
