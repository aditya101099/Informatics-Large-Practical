package uk.ac.ed.inf.aqmaps;
import java.util.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import com.google.gson.Gson;
import com.mapbox.geojson.*;
import java.io.*;
import com.mapbox.turf.*;

/**
* ReadWrite is a class that contains a number of static methods for reading files, writing to files, as well as other useful helper methods.
* 
* @author s1807827
* 
*/

public class ReadWrite {
	
	/**
	 * <p> This method converts a sensor's What3Words address to a Coordinate object.
	 * </p>
	 * @param w3w - The sensor's What3Words address
	 * @param client - the HttpClient to query to access the web server
	 * @param port - the port on which to connect to the web server
	 * @return The Coordinate of the sensor's What3Words address
	 */
	public static Coordinate toCoordinates(String w3w, HttpClient client, int port) {
		var urlString = "http://localhost:" + Integer.toString(port) + "/words/" + w3w.replace(".", "/") + "/details.json"; // Get the URL
		var request = HttpRequest.newBuilder() .uri(URI.create(urlString)).build(); // Get an HttpRequest
		try {
			var response = client.send(request, BodyHandlers.ofString()); // Try sending the request
			var details = new Gson().fromJson(response.body(), W3W.class);
			var coordinatesToChange = details.getCoordinates(); // Get the coordinates from the W3W object
			return new Coordinate(coordinatesToChange.getLng(), coordinatesToChange.getLat()); // Use getter methods to turn it into a Coordinate object
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return new Coordinate(0.0, 0.0); // If connecting to the server doesn't work, return the center of the Earth as the object
	}
	
	/**
	 * <p> This method converts a sensor's reading to a hexadecimal value denoting its marker's color.
	 * </p>
	 * @param reading - The reading from the sensor
	 * @return The hexadecimal value of the corresponding color, expressed as a String.
	 */
	public static String readingToHex(String reading) { 
		
		var readingInt = Double.parseDouble(reading);
		
		if (0 <= readingInt && readingInt < 32) { // Series of if-statements convert the reading to the corresponding hex code as per the coursework specification 
			return "#00ff00";
		} else if (32 <= readingInt && readingInt < 64) {
			return "#40ff00";
		} else if (64 <= readingInt && readingInt < 96) {
			return "#80ff00";
		} else if (96 <= readingInt && readingInt < 128) {
			return "#c0ff00";
		} else if (128 <= readingInt && readingInt < 160) {
			return "#ffc000";
		} else if (160 <= readingInt && readingInt < 192) {
			return "#ff8000";
		} else if (192 <= readingInt && readingInt < 224) {
			return "#ff4000";
		} else if (224 <= readingInt && readingInt < 256) {
			return "#ff0000";
		} else {
			return "#000000";
		}
	}
	
	/**
	 * <p> This method converts a sensor's reading to a string its marker's symbol.
	 * </p>
	 * @param reading - The reading from the sensor
	 * @return The string representing the type of the marker's symbol.
	 */
	public static String readingToMarker(String reading) { 
		
		var readingInt = Double.parseDouble(reading);
		
		if (0 <= readingInt && readingInt < 32) { // Series of if-statements convert the reading to the corresponding hex code as per the coursework specification 
			return "lighthouse";
		} else if (32 <= readingInt && readingInt < 64) {
			return "lighthouse";
		} else if (64 <= readingInt && readingInt < 96) {
			return "lighthouse";
		} else if (96 <= readingInt && readingInt < 128) {
			return "lighthouse";
		} else if (128 <= readingInt && readingInt < 160) {
			return "danger";
		} else if (160 <= readingInt && readingInt < 192) {
			return "danger";
		} else if (192 <= readingInt && readingInt < 224) {
			return "danger";
		} else if (224 <= readingInt && readingInt < 256) {
			return "danger";
		} else {
			return "cross";
		}
	
	}
	
	/**
	 * <p> This method makes a GeoJSON marker for a given sensor's address.
	 * </p>
	 * @param color - The color of the marker
	 * @param markerShape - The symbol of the marker
	 * @param location - The location of the marker, given as the sensor's What3Words address
	 * @param client - the HttpClient to query to access the web server
	 * @param port - the port on which to connect to the web server
	 * @return The marker at a given sensor's address as a GeoJSON feature.
	 */
	
	public static Feature makeMarker(String color, String markerShape, String location, HttpClient client, int port) {
		var sensorLocation = toCoordinates(location, client, port); // Get coordinates of sensor's location
		var p = Point.fromLngLat(sensorLocation.getLongitude(), sensorLocation.getLatitude()); // Convert to GeoJSON point
		var f = Feature.fromGeometry((Geometry) p); // Casts the point to a geometry, and converts it to a feature
		f.addStringProperty("marker-size", "medium");
		f.addStringProperty("location", location);
		f.addStringProperty("rgb-string", color);  // This line simply creates a property called rgb-string so that the hex string can be easily viewed
		f.addStringProperty("marker-color", color); // This line actually fills the polygon in the right color
		f.addStringProperty("marker-symbol", markerShape); 
		
		return f;
	}
	
	/**
	 * <p> This method returns the No-Fly Zones into a form that is used by other functions.
	 * </p>
	 * @param client - the HttpClient to query to access the web server
	 * @param noFlyURL - the address at the web server where details about the buildings are stored
	 * @return A list of the No-Fly Zones, expressed as GeoJSON polygons.
	 */
	public static ArrayList<Polygon> getBuildings(HttpClient client, String noFlyURL) throws IOException, InterruptedException {
        var request = HttpRequest.newBuilder().uri(URI.create(noFlyURL)).build(); // Get ready to issue request to fetch geojson file

        var response = client.send(request, BodyHandlers.ofString()); // Fetch geojson file
        List<Feature> features = FeatureCollection.fromJson(response.body()).features(); // Pass gson file to extract feature collection

        var buildings = new ArrayList<Polygon>(); // Create a list of polygons to hold the no fly zones
        
        for (Feature ftr: features) { // Iterate through each feature
        	buildings.add((Polygon) ftr.geometry()); // Get the geometry, cast to a polygon, and add to the list
        }
      
        return buildings;
	}
	
	
	/**
	 * <p> This method converts all of the drone's moves into one GeoJSON LineString feature to show its path.
	 * </p>
	 * @param moves - An ArrayList of MoveData objects, which is the record of moves the drone has made.
	 * @return A GeoJSON LineString depicting the drone's flightpath.
	 */
	public static Feature makeLine(ArrayList<MoveData> moves) {
		var pointsList = new ArrayList<Point>(); // Make a list that will hold all the points
		
		for (MoveData move: moves) { // iterate through the MoveData class
			pointsList.add(Point.fromLngLat(move.initialLong, move.initialLat)); // Make each initial point (as each destination will eventually be an origin) a GeoJSON Point and add that to the list of points

		}
		var l = LineString.fromLngLats(pointsList); // Convert the list into a GeoJSON LineString
		var f = Feature.fromGeometry((Geometry) l); // Cast to a geometry, make it into a feature
		return f;
	}
	
	/**
	 * <p> This method makes a GeoJSON marker for a given sensor's address provided that it has not been read.
	 * </p>
	 * @param location - The location of the marker, given as the sensor's What3Words address
	 * @param client - the HttpClient to query to access the web server
	 * @param port - the port on which to connect to the web server
	 * @return The marker at a given sensor's address as a GeoJSON feature.
	 */
	public static Feature makeUnfinishedMarker(String location, HttpClient client, int port) {
		var sensorLocation = toCoordinates(location, client, port);
		var p = Point.fromLngLat(sensorLocation.getLongitude(), sensorLocation.getLatitude());
		var f = Feature.fromGeometry((Geometry) p); // Casts the point to a geometry, and converts it to a feature
		f.addStringProperty("marker-size", "medium");
		f.addStringProperty("location", location);
		f.addStringProperty("rgb-string", "#aaaaaa");  // This line simply creates a property called rgb-string so that the hex string can be easily viewed
		f.addStringProperty("marker-color", "#aaaaaa"); // This line actually fills the polygon in the right color
		
		return f;
	}
	
	/**
	 * <p> This method outputs the drone's moves to a text file in a format that can be read by humans.
	 * </p>
	 * @param filename - The name of the file to write to.
	 * @param moveList - The ArrayList of MoveData objects which contain a record of the drone's moves.
	 */
	public static void writeMovesToFile(String filename, ArrayList<MoveData> moveList) {
		try {
			var fileWriter = new FileWriter(filename); // Create fileWriter object
			for (var move: moveList) { // Iterate through the list of moves, format each MoveData object into a String
					var line = Integer.toString(move.getMoveNumber()) + "," + Double.toString(move.getInitialLong()) + "," + Double.toString(move.getInitialLat()) + "," + Integer.toString(move.getHeading()) + "," + Double.toString(move.getDestLong()) + "," + Double.toString(move.getDestLat())+ "," + move.getW3w() + "\n";
					fileWriter.write(line); // Write each line

			}
		    fileWriter.close();
		    System.out.println("Successfully wrote to the file.");
		} catch (IOException e) {
			System.out.println("An error occurred.");
		    e.printStackTrace();
		}
	}
	
	/**
	 * <p> This method outputs the markers for the sensors that have been read, the markers for the sensors that haven't been read, and the LineString of the drone's flight path to a GeoJSON file that can be parsed by a GeoJSON parser.
	 * </p>
	 * @param filename - The name of the file to write to.
	 * @param readings - The ArrayList of GeoJSON features that contain the markers for the visited and unvisited sensors, as well as the LineString that shows the drone's flight path.
	 */
	public static void writeReadingstoGeoJSON(String filename, ArrayList<Feature> readings) {
		FeatureCollection fc = FeatureCollection.fromFeatures(readings); // Turn the list of features into a feature collection
		try { // Try block used in the event of a failure
	        var fileWriter = new FileWriter(filename); // Creates a new filewriter object to be written to, names it heatmap.geojson
	        fileWriter.write(fc.toJson()); // Converts the feature collection to a json file, and writes it to the file just created
	        fileWriter.close(); // Closes the file
	        System.out.println("Successfully wrote to the file."); // Prints a confirmation message
	      } catch (IOException e) { // In the event that an error occurs, it is triggered
	        System.out.println("An error occurred."); // Error message displayed
	        e.printStackTrace();
	      }		
	}

	

}
