package uk.ac.ed.inf.aqmaps;

/**
* W3W is the main entity that models the details of a What3Words file when deserialized from a JSON string.
* 
* @author s1807827
* 
*/
public class W3W {
	
	
	/**
	* The country the What3Words square is in.
	*/
	public String country;
	
	/**
	* The square itself, defined by its Northeast and Southwest corners.
	*/
	public Square square;
	
	/**
	* A class that defines the What3Words square.
	*/
	public static class Square {
		
		/**
		* The Southwest corner of the What3Words square.
		*/
		public Southwest southwest;
		
		/**
		* A class that defines what a Southwest corner is.
		*/
		public static class Southwest {
			
			/**
			* The longitude of the Southwest corner.
			*/
			public double lng;
			
			/**
			* The latitude of the Southwest corner.
			*/
			public double lat;
			
			/**
			 * <p> This method returns the Southwest corner's longitude.
			 * </p>
			 * @return The Southwest corner's longitude.
			 */
			public double getLng() {
				return lng;
			}
			
			/**
			 * <p> This method returns the Southwest corner's latitude.
			 * </p>
			 * @return The Southwest corner's latitude.
			 */
			public double getLat() {
				return lat;
			}
		}
		
		/**
		 * <p> This method returns the Southwest corner.
		 * </p>
		 * @return The Southwest corner.
		 */
		public Southwest getSouthwest() {
			return southwest;
		}
		
		/**
		* The Northeast corner of the What3Words square.
		*/
		Northeast northeast;
		
		/**
		* A class that defines what a Northeast corner is.
		*/
		public static class Northeast {
			/**
			* The longitude of the Northeast corner.
			*/
			public double lng;
			
			/**
			* The latitude of the Northeast corner.
			*/
			public double lat;
			
			/**
			 * <p> This method returns the Northeast corner's longitude.
			 * </p>
			 * @return The Northeast corner's longitude.
			 */
			public double getLng() {
				return lng;
			}
			
			/**
			 * <p> This method returns the Northeast corner's latitude.
			 * </p>
			 * @return The Northeast corner's latitude.
			 */
			public double getLat() {
				return lat;
			}
		}
		
		/**
		 * <p> This method returns the Northeast corner.
		 * </p>
		 * @return The Northeast corner.
		 */
		public Northeast getNortheast() {
			return northeast;
		}

	}
	
	/**
	* The nearest place to the What3Words square (such as a town).
	*/
	public String nearestPlace;
	
	/**
	* The coordinates of the center of the square.
	*/
	public Coordinates coordinates;
	
	/**
	* A class that defines what Coordinates are.
	*/
	public static class Coordinates {
		
		/**
		* The longitude of the center of the square.
		*/
		public double lng;
		
		/**
		* The latitude of the center of the square.
		*/
		public double lat;
		
		/**
		 * <p> This method returns the center's longitude.
		 * </p>
		 * @return The center's longitude.
		 */
		public double getLng() {
			return lng;
		}
		
		/**
		 * <p> This method returns the center's latitude.
		 * </p>
		 * @return The Northeast center's latitude.
		 */
		public double getLat() {
			return lat;
		}
	}
	
	/**
	* The What3Words address of the square.
	*/
	public String words;
	
	/**
	* The language the address is expressed in.
	*/
	public String language;
	
	/**
	* A URL to the map of the square on the web.
	*/
	public String map;
	
	/**
	 * <p> This method returns the What3Words address' coordinates.
	 * </p>
	 * @return The What3Words address' coordinates.
	 */
	public Coordinates getCoordinates() {
		return coordinates;
	}
	
	/**
	 * <p> This method returns the What3Words address' country.
	 * </p>
	 * @return The What3Words address' country.
	 */
	public String getCountry() {
		return country;
	}
	
	/**
	 * <p> This method returns the What3Words address' square.
	 * </p>
	 * @return The What3Words address' square.
	 */
	public Square getSquare() {
		return square;
	}
	
	/**
	 * <p> This method returns the What3Words address' language.
	 * </p>
	 * @return The What3Words address' language.
	 */
	public String getLanguage() {
		return language;
	}
	
	/**
	 * <p> This method returns the What3Words address' web URL.
	 * </p>
	 * @return The What3Words address' web URL.
	 */
	public String getMap() {
		return map;
	}

}
