package uk.ac.ed.inf.aqmaps;

/**
* Coordinate is the main entity that models (longitude, latitude) pairs for the drone to use.
* 
* @author s1807827
* 
*/
public class Coordinate {
	
	/**
	* The longitude component of the coordinate.
	*/
	public double longitude;
	
	/**
	* The latitude component of the coordinate.
	*/
	public double latitude;
	
	public Coordinate(double longitude, double latitude) {
		this.longitude = longitude;
		this.latitude = latitude;
	}

	/**
	 * <p> This method returns the longitude of the given coordinate.
	 * </p>
	 * @return The longitude of the given coordinate.
	 */
	
	public double getLongitude() {
		return this.longitude;
	}

	/**
	 * <p> This method returns the latitude of the given coordinate.
	 * </p>
	 * @return The latitude of the given coordinate.
	 */
	public double getLatitude() {
		return this.latitude;
	}
	
	/**
	 * <p> This method returns the distance between any two coordinates, computed by Euclidean distance.
	 * </p>
	 * @param x - The first coordinate
	 * @param y - The second coordinate
	 * @return The distance between the two coordinates, in degrees.
	 */
	public static double getDistance(Coordinate x, Coordinate y) {
		return Math.sqrt(Math.pow((y.getLongitude()-x.getLongitude()), 2) + Math.pow((y.getLatitude() - x.getLatitude()), 2));
	}

}
