package uk.ac.ed.inf.aqmaps;

/**
* MoveData is the main entity that keeps a detailed record of the drone's moves.
* 
* @author s1807827
* 
*/

public class MoveData {
	
	/**
	* The current move made by the drone, enumerated.
	*/
	public int moveNumber;
	
	/**
	* The initial longitude of the drone prior to its move.
	*/
	public double initialLong;
	
	/**
	* The initial latitude of the drone prior to its move.
	*/
	public double initialLat;
	
	/**
	* The direction the drone moved in, in degrees.
	*/
	public int heading;
	
	/**
	* The final longitude of the drone after the move.
	*/
	public double destLong;
	
	/**
	* The final latitude of the drone after the move.
	*/
	public double destLat;
	
	/**
	* The What3Words of the address read by the sensor if a reading was taken; null otherwise.
	*/
	public String w3w;
	
	
	public MoveData(int moveNumber, double initialLong, double initialLat, int heading, double destLong, double destLat, String w3w) {
		this.moveNumber = moveNumber;
		this.initialLong = initialLong;
		this.initialLat = initialLat;
		this.heading = heading;
		this.destLong = destLong;
		this.destLat = destLat;
		this.w3w = w3w;
	}

	/**
	 * <p> This method returns which move the drone has just completed, based on its enumeration.
	 * </p>
	 * @return The move the drone has just completed.
	 */
	public int getMoveNumber() {
		return moveNumber;
	}


	/**
	 * <p> This method returns the initial longitude the drone was at.
	 * </p>
	 * @return The initial longitude the drone was at.
	 */
	public double getInitialLong() {
		return initialLong;
	}

	/**
	 * <p> This method returns the initial latitude the drone was at.
	 * </p>
	 * @return The initial latitude the drone was at.
	 */
	public double getInitialLat() {
		return initialLat;
	}



	/**
	 * <p> This method returns the direction the drone moved in, in degrees.
	 * </p>
	 * @return The direction the direction the drone moved in, in degrees.
	 */
	public int getHeading() {
		return heading;
	}



	/**
	 * <p> This method returns the destination longitude the drone moved to.
	 * </p>
	 * @return The destination longitude the drone moved to.
	 */
	public double getDestLong() {
		return destLong;
	}




	/**
	 * <p> This method returns the destination latitude the drone moved to.
	 * </p>
	 * @return The destination latitude the drone moved to.
	 */
	public double getDestLat() {
		return destLat;
	}


	/**
	 * <p> This method returns the sensor the drone read, if there was one.
	 * </p>
	 * @return The sensor the drone read, if there was one, and null otherwise.
	 */
	public String getW3w() {
		return w3w;
	}
	
	/**
	 * <p> This method sets the w3w field of the MoveData to the What3Words address of the sensor the drone just read.
	 * </p>
	 * @param w3w  - the What3Words address of the sensor the drone just read.
	 */
	public void setW3w(String w3w) {
		this.w3w = w3w;
	}


}
